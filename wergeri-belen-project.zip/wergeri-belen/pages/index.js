import { useState, useRef } from 'react';
import Head from 'next/head';

const TGT_LANGS = [
  { v:'ckb', l:'کوردی سۆرانی' }, { v:'kmr', l:'کوردی بادینی' },
  { v:'ar',  l:'عەرەبی' },       { v:'en',  l:'ئینگلیزی' },
  { v:'fa',  l:'فارسی' },        { v:'tr',  l:'تورکی' },
];

function parseSRT(raw) {
  const text = raw.replace(/\r\n/g,'\n').replace(/\r/g,'\n').trim();
  const out = [];
  for (const b of text.split(/\n\s*\n/)) {
    const rows = b.trim().split('\n');
    if (rows.length < 2) continue;
    const time = rows[1];
    const txt = rows.slice(2).join(' ').replace(/<[^>]+>/g,'').trim();
    if (time.includes('-->') && txt) out.push({ num: rows[0].trim(), time, text: txt });
  }
  if (!out.length)
    return text.split('\n').filter(l=>l.trim()).map((t,i)=>({ num:String(i+1), time:'', text:t.trim() }));
  return out;
}

function parseNumbered(text, n) {
  return Array.from({length:n}, (_,i) => {
    const m = text.match(new RegExp(`\\[${i+1}\\]\\s*(.+?)(?=\\[${i+2}\\]|$)`, 's'));
    return m ? m[1].trim() : '';
  });
}

function dlBlob(content, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], {type:'text/plain;charset=utf-8'}));
  a.download = name; a.click();
}

export default function Home() {
  const [tab, setTab]       = useState('upload');
  const [src, setSrc]       = useState([]);
  const [done, setDone]     = useState([]);
  const [tgt, setTgt]       = useState('ckb');
  const [mode, setMode]     = useState('natural');
  const [batch, setBatch]   = useState(15);
  const [bilStyle, setBil]  = useState('stacked');
  const [dlName, setDlName] = useState('wergeri_belen');
  const [manText, setMan]   = useState('');
  const [loading, setLoad]  = useState(false);
  const [pct, setPct]       = useState(0);
  const [pLabel, setPL]     = useState('');
  const [upMsg, setUpMsg]   = useState(null);
  const [resMsg, setResMsg] = useState(null);
  const [toast, setToast]   = useState('');
  const [toastOn, setTOn]   = useState(false);
  const ttRef = useRef(null);

  function showToast(msg) {
    setToast(msg); setTOn(true);
    clearTimeout(ttRef.current);
    ttRef.current = setTimeout(() => setTOn(false), 3200);
  }

  function loadFile(file) {
    const r = new FileReader();
    r.onload = e => {
      const lines = parseSRT(e.target.result);
      setSrc(lines); setDone([]);
      setUpMsg({ t:'ok', m:`✅ ${file.name} — ${lines.length} دەق بارکرا` });
      showToast(`📁 ${lines.length} ژێرنووس بارکرا`);
    };
    r.readAsText(file, 'utf-8');
  }

  async function translate(lines) {
    if (!lines.length) { showToast('❌ سەرەتا فایلێک بارکە'); return; }
    setTab('result'); setLoad(true); setDone([]); setPct(0);
    setResMsg({ t:'in', m:'⏳ وەرگێڕان دەستپێکرد...' });

    const langName =
      tgt==='ckb' ? 'Kurdish Sorani (Central Kurdish, Arabic script, natural fluent for drama/film)' :
      tgt==='kmr' ? 'Kurdish Kurmanji (Northern Kurdish, Latin script)' :
      tgt==='ar'  ? 'Arabic' : tgt==='fa' ? 'Persian' : tgt==='tr' ? 'Turkish' : 'English';

    const modeNote =
      mode==='cinematic' ? 'Use cinematic dramatic tone.' :
      mode==='literal'   ? 'Translate as literally as possible.' :
      'Translate naturally, preserve emotion and character voice.';

    const total = lines.length; let doneN = 0; const result = [];

    try {
      for (let i = 0; i < lines.length; i += batch) {
        const chunk = lines.slice(i, i + batch);
        const prompt =
          `You are a professional subtitle translator for ${langName}.\n${modeNote}\n` +
          `Translate each numbered line. Output ONLY in [1] text [2] text format. No notes.\n\n` +
          chunk.map((l,j) => `[${j+1}] ${l.text}`).join('\n');

        const res = await fetch('/api/translate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, max_tokens: 4096 }),
        });

        if (!res.ok) {
          const e = await res.json().catch(() => ({}));
          throw new Error(e?.error || `هەڵە ${res.status}`);
        }
        const data = await res.json();
        const translated = parseNumbered(data.text || '', chunk.length);

        chunk.forEach((l,j) => result.push({ num:l.num, time:l.time, ku:translated[j]||l.text, src:l.text }));
        doneN += chunk.length;
        const p = Math.round(doneN / total * 100);
        setPct(p); setPL(`${doneN} / ${total} دەق وەرگێڕدرا`);
        setDone([...result]);
      }
      setResMsg({ t:'ok', m:`✅ وەرگێڕان تەواو بوو! — ${result.length} دەق` });
      showToast('🎉 وەرگێڕان تەواو بوو!');
    } catch(err) {
      setResMsg({ t:'er', m:'❌ هەڵە: ' + err.message });
      showToast('❌ ' + err.message);
    } finally {
      setLoad(false);
    }
  }

  return (
    <>
      <Head>
        <title>وەرگێڕی بەڵێن — Subtitle Translator</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700&family=Cairo:wght@400;600;700&display=swap" rel="stylesheet" />
      </Head>

      <div className="bg" /><div className="grid-bg" />

      <div className={`toast ${toastOn ? 'on' : ''}`}>{toast}</div>

      <div className="wrap">
        <header>
          <div className="ring">🎬</div>
          <h1>WERGÊRÎ BELÊN</h1>
          <p className="sub">وەرگێڕی بەڵێن — Subtitle Translator</p>
          <span className="vip">✦ VIP EDITION ✦</span>
        </header>

        <div className="dhr"><span>⬡</span></div>

        {/* STATS */}
        <div className="stats">
          {[
            [src.length ? '1' : '0', 'فایل'],
            [String(src.length), 'دەق'],
            [String(done.length), 'وەرگێڕدرا'],
            [tgt==='ckb'?'سۆرانی':tgt==='kmr'?'بادینی':tgt.toUpperCase(), 'زمان'],
          ].map(([n,l]) => (
            <div key={l} className="stat">
              <div className="stn">{n}</div>
              <div className="stl">{l}</div>
            </div>
          ))}
        </div>

        {/* TABS */}
        <div className="tabs">
          {[
            {k:'upload',l:'📁 بارکردن'},{k:'text',l:'✏️ دەق'},
            {k:'result',l:'🌐 ئەنجام'},{k:'settings',l:'⚙️ ڕێکخستن'}
          ].map(t => (
            <button key={t.k} className={`tab ${tab===t.k?'on':''}`} onClick={() => setTab(t.k)}>{t.l}</button>
          ))}
        </div>

        {/* UPLOAD */}
        {tab==='upload' && <>
          <div className="panel">
            <div className="pt">بارکردنی فایل</div>
            <div className="drop"
              onDragOver={e => { e.preventDefault(); e.currentTarget.classList.add('ov'); }}
              onDragLeave={e => e.currentTarget.classList.remove('ov')}
              onDrop={e => { e.preventDefault(); e.currentTarget.classList.remove('ov'); const f=e.dataTransfer.files[0]; if(f) loadFile(f); }}
              onClick={() => document.getElementById('fi').click()}>
              <span className="di">💎</span>
              <div className="dt">فایلی ژێرنووست لێرە دابنێ یان کلیک بکە</div>
              <div className="ds">کێش بیێنە ئێرە</div>
              <div className="fmts">{['SRT','VTT','ASS','SSA','TXT'].map(f=><span key={f} className="fmt">{f}</span>)}</div>
              <input id="fi" type="file" accept=".srt,.vtt,.ass,.ssa,.txt" style={{display:'none'}}
                onChange={e => { const f=e.target.files[0]; if(f) loadFile(f); }} />
            </div>
            {upMsg && <div className={`al ${upMsg.t}`}>{upMsg.m}</div>}
          </div>

          <div className="panel">
            <div className="pt">زمان و مۆد</div>
            <div className="g2">
              <div className="cg"><div className="cl">وەرگێڕبۆ</div>
                <select value={tgt} onChange={e=>setTgt(e.target.value)}>
                  {TGT_LANGS.map(l=><option key={l.v} value={l.v}>{l.l}</option>)}
                </select></div>
              <div className="cg"><div className="cl">مۆد</div>
                <select value={mode} onChange={e=>setMode(e.target.value)}>
                  <option value="natural">سروشتی</option>
                  <option value="cinematic">سینەمایی</option>
                  <option value="literal">ڕاستەوخۆ</option>
                </select></div>
            </div>
            <div className="br">
              <button className="btn btng" disabled={loading} onClick={() => translate(src)}>
                {loading ? <>وەرگێڕان... <span className="spin" /></> : '✨ وەرگێڕانی دەست پێبکە'}
              </button>
              <button className="btn btno bsm" onClick={() => { setSrc([]); setDone([]); setUpMsg(null); showToast('🗑️ پاکردنەوە'); }}>🗑️</button>
            </div>
          </div>
        </>}

        {/* TEXT */}
        {tab==='text' && <div className="panel">
          <div className="pt">دەق بنووسە یان پەیست بکە</div>
          <textarea rows={9} value={manText} onChange={e=>setMan(e.target.value)}
            placeholder={"1\n00:00:01,000 --> 00:00:04,000\nHello, welcome to our show."} />
          <div className="br">
            <button className="btn btng" disabled={loading} onClick={() => { const l=parseSRT(manText); setSrc(l); translate(l); }}>
              {loading ? <>وەرگێڕان... <span className="spin" /></> : '✨ وەرگێڕان'}
            </button>
            <button className="btn btno bsm" onClick={() => setMan('')}>🗑️</button>
          </div>
        </div>}

        {/* RESULT */}
        {tab==='result' && <div className="panel">
          <div className="pt">ئەنجامی وەرگێڕان</div>
          {loading && <div className="pw">
            <div className="pi"><span>{pLabel||'چاوەڕوانبە...'}</span><span>{pct}%</span></div>
            <div className="pb"><div className="pf" style={{width:pct+'%'}} /></div>
          </div>}
          {resMsg && <div className={`al ${resMsg.t}`}>{resMsg.m}</div>}

          {done.length > 0 && <>
            <div className="sb">
              <div className="shd">
                <div className="shc">🇮🇶 کوردی</div>
                <div className="shc">🌐 سەرچاوە</div>
              </div>
              {done.map((l,i) => (
                <div key={i} className="sr">
                  <div className="sku">
                    {l.time && <span className="st">{l.time}</span>}
                    <span className="sn">{l.num}</span>{l.ku}
                  </div>
                  <div className="sen">
                    {l.time && <span className="st">{l.time}</span>}
                    <span className="sn">{l.num}</span>{l.src}
                  </div>
                </div>
              ))}
            </div>
            <div className="pt" style={{marginTop:16}}>داگرتن</div>
            <div className="dg">
              {[
                {i:'📄',n:'کوردی SRT',f:'.srt',fn:()=>dlBlob(done.map(l=>`${l.num}\n${l.time}\n${l.ku}\n`).join('\n'),`${dlName}_ku.srt`)},
                {i:'🎞️',n:'کوردی VTT',f:'.vtt',fn:()=>dlBlob('WEBVTT\n\n'+done.map(l=>`${l.time.replace(',','.')}\n${l.ku}\n`).join('\n'),`${dlName}_ku.vtt`)},
                {i:'🌐',n:'دووزمانی',f:'.srt',fn:()=>dlBlob(done.map(l=>`${l.num}\n${l.time}\n${bilStyle==='stacked'?l.ku+'\n'+l.src:l.ku+' | '+l.src}\n`).join('\n'),`${dlName}_bilingual.srt`)},
                {i:'📝',n:'دەق سادە',f:'.txt',fn:()=>dlBlob(done.map(l=>l.ku).join('\n'),`${dlName}_ku.txt`)},
              ].map(d => (
                <div key={d.n} className="dc" onClick={() => { d.fn(); showToast('⬇️ داگرتن دەستپێکرد'); }}>
                  <div className="di2">{d.i}</div><div className="dn">{d.n}</div><div className="df">{d.f}</div>
                </div>
              ))}
            </div>
          </>}
          {!loading && !done.length && !resMsg && (
            <div className="emp"><div className="empi">🎬</div><div>سەرەتا فایلێک بارکە یان دەقێک بنووسە</div></div>
          )}
        </div>}

        {/* SETTINGS */}
        {tab==='settings' && <div className="panel">
          <div className="pt">ڕێکخستنەکان</div>
          <div className="g2">
            <div className="cg"><div className="cl">ژمارەی دەق / داوا</div>
              <input type="number" value={batch} min={1} max={50} style={{backgroundImage:'none'}} onChange={e=>setBatch(+e.target.value)} /></div>
            <div className="cg"><div className="cl">شیوەی دووزمانی</div>
              <select value={bilStyle} onChange={e=>setBil(e.target.value)}>
                <option value="stacked">سەرەکی + خوارەوە</option>
                <option value="side">لای یەکتر</option>
              </select></div>
            <div className="cg" style={{gridColumn:'1/-1'}}><div className="cl">ناوی فایلی داگرتن</div>
              <input type="text" value={dlName} onChange={e=>setDlName(e.target.value)} dir="ltr" style={{backgroundImage:'none'}} /></div>
          </div>
        </div>}

        <footer>✦ وەرگێڕی بەڵێن VIP ✦ دروستکراوە بۆ دراما و فیلم ✦</footer>
      </div>
    </>
  );
}
