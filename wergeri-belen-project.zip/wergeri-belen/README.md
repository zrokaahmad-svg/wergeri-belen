# وەرگێڕی بەڵێن — Subtitle Translator VIP

## چۆن هۆست بکەیت (بەبێ پارە)

### پێشمەرجەکان
- ئەکاونتی GitHub: github.com
- ئەکاونتی Vercel: vercel.com
- کلیلی Anthropic API: console.anthropic.com

---

### هەنگاو ١ — GitHub ئەکاونت دروست بکە
1. بچۆ بۆ github.com
2. "Sign up" کلیک بکە
3. ئیمەیل + پاسوۆرد بنووسە
4. ئەکاونتەکە پشتڕاست بکەوە

### هەنگاو ٢ — Repository نوێ دروست بکە
1. لە GitHub بچۆ بۆ "New repository"
2. ناوی بنووسە: `wergeri-belen`
3. Public هەڵبژێرە
4. "Create repository" کلیک بکە

### هەنگاو ٣ — فایلەکان بارکە
هەر فایلێک لەم فۆڵدەرانەوە بارکە بۆ GitHub:
- `pages/index.js`
- `pages/_app.js`
- `pages/api/translate.js`
- `styles/globals.css`
- `package.json`

### هەنگاو ٤ — Vercel هۆست
1. بچۆ بۆ vercel.com
2. "Sign up with GitHub" کلیک بکە
3. "New Project" → repository خۆت هەڵبژێرە
4. **Environment Variables** زیاد بکە:
   - Name: `ANTHROPIC_API_KEY`
   - Value: کلیلەکەت (`sk-ant-...`)
5. "Deploy" کلیک بکە

### ئەنجام
وێبسایتەکەت ئامادەیە! لینکێکی وەک ئەمە وەردەگریت:
`https://wergeri-belen.vercel.app`

---

## کلیلی Anthropic API لێت وەربگرە
1. بچۆ بۆ: console.anthropic.com
2. ئەکاونت دروست بکە
3. "API Keys" → "Create Key"
4. $5 کرێدیتی خۆڕای وەردەگریت بۆ دەستپێکردن
